define(['rjsResolver'],function(resolver){'use strict';function hideLoader($loader){$loader.parentNode.removeChild($loader);}
function init(config,$loader){resolver(hideLoader.bind(null,$loader));}
return init;});