define([],function(){'use strict';function resultWrapper(isValid,isPotentiallyValid){return{isValid:isValid,isPotentiallyValid:isPotentiallyValid};}
return function(value,maxLength){var DEFAULT_LENGTH=3;maxLength=maxLength||DEFAULT_LENGTH;if(!/^\d*$/.test(value)){return resultWrapper(false,false);}
if(value.length===maxLength){return resultWrapper(true,true);}
if(value.length<maxLength){return resultWrapper(false,true);}
if(value.length>maxLength){return resultWrapper(false,false);}};});