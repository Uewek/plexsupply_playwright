(function(){var userAgent=navigator.userAgent,html=document.documentElement,gap='';if(html.className){gap=' ';}
if(userAgent.match(/Trident.*rv[ :]*11\./)){html.className+=gap+'ie11';}})();